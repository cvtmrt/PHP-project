<?php

// example : ahmet.yilmaz7654@ug.bilkent.edu.tr
const EMAIL = 'ali.eray@ug.bilkent.edu.tr' ;

// your password
const EPASSWORD = 'b9u18QcT' ;

// your fullname
// example : Ahmet Yılmaz
const FULLNAME = "Ali Eray" ;

// About email : Recepient email address and Subject field
const TO = "erayali2003@gmail.com" ;   // ahmet.yilmaz7654@ug.bilkent.edu.tr
const SUBJECT = "CTIS 256 Test" ;